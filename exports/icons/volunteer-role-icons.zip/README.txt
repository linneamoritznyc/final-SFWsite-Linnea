Soil Food Web Foundation, volunteer role icons (21).
PNG 512px transparent: upload these to the WordPress Media Library and use them in the flip boxes, shown at 48 x 48 px.
SVG: the same icons as vector files (Food Web Green #156826). WordPress only accepts SVG with a plugin such as Safe SVG.
Numbers match the order of the role cards on the Volunteer page.
